/*
Source: https://docs.oracle.com/javase/tutorial/jdbc/basics/processingsqlstatements.html?fbclid=IwAR21cYhbpAQlhnnlY1SDYW2_sIIm-Ku6COyiKhdsseT4RdXU_4vlj9L7usw#creating_statements
        https://openclassrooms.com/fr/courses/26832-apprenez-a-programmer-en-java/26830-liez-vos-tables-avec-des-objets-java-le-pattern-dao
 */
package controleur;

import modele.Eleve;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author louis
 */
public class EleveDAO extends DAO<Eleve> {
    private Statement stmt;
    //private Connection conn;
    
    public EleveDAO(Connection conn) {
    super(conn);
    this.stmt = null;
  }

    @Override
  public boolean add(Eleve obj) {
      
    String query =  "INSERT INTO eleve (id,nom, prenom, classe, bulletin) VALUES (Default,'"+obj.getNom()+"','"+obj.getPrenom()+
                "',"+obj.getClasse()+
                ","+obj.getBulletin()+")"; 
     try{
         this.stmt = this.connect.createStatement(); 
         int rs = this.stmt.executeUpdate(query); 
     }catch(SQLException e )
     {
         System.out.println(e);
     } finally 
     {
         if (this.stmt != null )
         {
             try {
                 this.stmt.close();
             } catch (SQLException ex) {
                 Logger.getLogger(EleveDAO.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
     }
    
    return false;
  }

  public boolean supp(Eleve obj) {
      
      String query =  "DELETE FROM eleve WHERE (id="+obj.getId()+")"; 
     try{
         this.stmt = this.connect.createStatement(); 
         int rs = this.stmt.executeUpdate(query); 
     }catch(SQLException e )
     {
         System.out.println(e);
     } finally 
     {
         if (this.stmt != null )
         {
             try {
                 this.stmt.close();
             } catch (SQLException ex) {
                 Logger.getLogger(EleveDAO.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
     }
    return false;
  }
   
  public boolean update(Eleve obj) {
      
    String query =  "UPDATE eleve SET id="+obj.getId()+",nom='"+obj.getNom()+"',prenom='"+obj.getPrenom()+
                "',classe="+obj.getClasse()+
                ",bulletin="+obj.getBulletin()+" WHERE (id="+obj.getId()+")"; 
    System.out.println(query);
     try{
         this.stmt = this.connect.createStatement(); 
         int rs = this.stmt.executeUpdate(query); 
     }catch(SQLException e )
     {
         System.out.println(e);
     } finally 
     {
         if (this.stmt != null )
         {
             try {
                 this.stmt.close();
             } catch (SQLException ex) {
                 Logger.getLogger(EleveDAO.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
     }
   return false;
  }
  
  
  public Eleve find(int id) {
        Eleve eleve = new Eleve();      
      
    try {
        ResultSet result = this.connect.createStatement(
        ResultSet.TYPE_SCROLL_INSENSITIVE,
        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM eleve WHERE id = " + id);
        
        if(result.first())
        eleve = new Eleve(
          id,  
          result.getString("nom"),
          result.getString("prenom"),
          Integer.parseInt(result.getString("classe")),
          Integer.parseInt(result.getString("bulletin")));         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return eleve;
  }
  
}
