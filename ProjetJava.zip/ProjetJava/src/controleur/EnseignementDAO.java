/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;
import java.sql.Connection;
import modele.Enseignement;
/**
 *
 * @author louis
 */
public class EnseignementDAO extends DAO<Enseignement> {
     public EnseignementDAO(Connection conn) {
    super(conn);
  }

  public boolean add(Enseignement obj) {
    return false;
  }

  public boolean supp(Enseignement obj) {
    return false;
  }
   
  public boolean update(Enseignement obj) {
    return false;
  }
 /* 
  public Enseignement find(int id) {
    
  }
*/
}
