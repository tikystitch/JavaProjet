/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

/**
 *
 * @author alexa
 */
import java.awt.BorderLayout;
import static java.awt.BorderLayout.CENTER;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;


public class inscriptionframe extends JFrame
{
  protected JPanel container=new JPanel();
  
  public inscriptionframe()
  {
    container.setLayout(null);
    this.setTitle("Inscription");
    //Pour affiche la fenêtre en grand s
    this.setSize(800,600);
    this.setLocationRelativeTo(null);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //Déclaration zone de remplissage
    JPanel form = new JPanel(); 
    form.setSize(400,300);
    JPanel bouton=new JPanel();
  
    //Contenu de la combobox
    Object[] classe = new Object[]{"ING1", "ING2", "ING3", "ING4", "ING5"};
    JComboBox combo = new JComboBox(classe);
    
    //Contenu de la grille:
    JLabel nom= new JLabel();
    nom.setLayout(null);
    nom.setBounds(50, 50, 100, 100);
    nom.setFont(new Font("Times New Roman",Font.BOLD,16));
    nom.setText("Nom :");
    JLabel prenom=new JLabel();
    prenom.setLayout(null);
    prenom.setFont(new Font("Times New Roman",Font.BOLD,16));
    prenom.setText("Prenom :");
    JLabel nomclasse=new JLabel();
    nomclasse.setLayout(null);
    nomclasse.setFont(new Font("Times New Roman",Font.BOLD,16));
    nomclasse.setText("Classe :");
    JTextField remplinom=new JTextField();
    
    JTextField rempliprenom=new JTextField();
    
    //Déclaration du bouton
    JButton valide=new JButton("Valider");
    valide.setLayout(null);
    valide.setHorizontalAlignment(SwingConstants.RIGHT);
    //Déclaration du titre
    JLabel label= new JLabel();
    
    //Mise en page du panel conteneur
    container.setLayout(new BorderLayout());
    
    //Police du titre
    label.setLayout(null);
    label.setFont(new Font("Times New Roman",Font.BOLD,26));
    label.setText("Inscription d'Eleve");
    container.add("North",label);
    //Positionnement du titre
    Border lineborder = BorderFactory.createLineBorder(Color.black, 1);
    form.setBorder(lineborder);
    label.setHorizontalAlignment(SwingConstants.CENTER);
    bouton.add(valide);
    form.add(nom);
    container.add("Center",form);
    container.add("South",bouton);
    this.add(container);
    this.setVisible(true);
  }
  
  
}
